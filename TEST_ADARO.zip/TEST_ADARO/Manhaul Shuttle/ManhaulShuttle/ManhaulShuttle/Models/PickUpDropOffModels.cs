﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ManhaulShuttle.Models
{
    public class PickUpDropOffModels
    {
        public string Id_PickUpDropOff { get; set; }
        public string Id_Route { get; set; }
        public string Route { get; set; }
        public string Time { get; set; }
        public string Type { get; set; }
        public string PickUpDropOff { get; set; }

        public List<RouteModels> RouteList { get; set; }
    }
}