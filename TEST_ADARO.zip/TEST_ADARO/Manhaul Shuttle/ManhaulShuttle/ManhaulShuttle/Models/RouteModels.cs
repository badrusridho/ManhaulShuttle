﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ManhaulShuttle.Models
{
    public class RouteModels
    {
        public string Id_Route { get; set; }
        public string Route { get; set; }
    }
}