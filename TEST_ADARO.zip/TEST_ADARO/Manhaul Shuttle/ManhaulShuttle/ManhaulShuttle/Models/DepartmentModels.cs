﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ManhaulShuttle.Models
{
    public class DepartmentModels
    {
        public string Id_Department { get; set; }
        public string Department { get; set; }
    }
}