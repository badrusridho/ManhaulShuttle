﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ManhaulShuttle.Models
{
    public class ScheduleModels
    {
        public string Id_Schedule { get; set; }
        public string Id_Route { get; set; }
        public string Route { get; set; }
        public string Department { get; set; }
        public string PickUp { get; set; }
        public string DropOff { get; set; }
        public string Time { get; set; }
        public string Name { get; set; }
        public string Id_Department { get; set; }
        public string Id_PickUp { get; set; }
        public string Id_DropOff { get; set; }

        public List<RouteModels> RouteList { get; set; }
        public List<DepartmentModels> DepartmentList { get; set; }
    }
}