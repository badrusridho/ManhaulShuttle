﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ManhaulShuttle.Models;
using ManhaulShuttle.Repositories.Route;
using MyDAL;

namespace ManhaulShuttle.Controllers
{
    public class RouteController : Controller
    {
        //
        // GET: /Route/

        #region "Settup Connection"

        private DataConnection dCon;
        private DbConnection SQLConnnection;
        private DbTransaction SQLTransaction;

        #region "Connection To SQL Server"

        //========== OPEN CONNECTION TO SQL SERVER ==========//
        //===================================================//

        private void SQLConnect()
        {
            dCon = new DataConnection();
            dCon.Provider = System.Configuration.ConfigurationManager.AppSettings["Provider"];
            dCon.ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"].ToStr();
            if (SQLConnnection != null)
            {
                if (SQLConnnection.State == ConnectionState.Closed)
                {
                    SQLConnnection = dCon.CreateConnection();
                    SQLConnnection.Open();
                }
            }
            else
            {
                SQLConnnection = dCon.CreateConnection();
                SQLConnnection.Open();
            }
        }

        //========== CLOSE CONNECTION TO SQL SERVER =========//
        //===================================================//
        private void SQLDisconnect()
        {
            if (SQLConnnection.State != ConnectionState.Open)
                return;

            SQLConnnection.Close();
            SQLConnnection.Dispose();
        }

        #endregion

        #endregion

        public ActionResult Index()
        {
            SQLConnect();
            List<RouteModels> list = new List<RouteModels>();
            RouteRepository repo = new RouteRepository();
            repo.Connection = SQLConnnection;
            list = repo.GetRoute(new string[,] { { "", "", "" } });
            SQLDisconnect();
            return View(list);
        }

        public ActionResult PagesRoute(string id)
        {
            try
            {
                RouteModels dm = new RouteModels();
                RouteRepository repo = new RouteRepository();

                if (id.ToStr() != "")
                {
                    SQLConnect();
                    repo.Connection = SQLConnnection;
                    dm = repo.GetSelectedRoute(new string[,] { { "Id_Route", "@Id_Route", id } });
                    SQLDisconnect();
                }

                return View(dm);
            }
            catch (Exception ex)
            {
                Response.Cookies["Error"].Value = ex.Message;
                return RedirectToAction("Index", "Route");
            }
        }

        #region "CRUD DEPARTMENT"

        [HttpPost]
        public ActionResult PagesRoute(FormCollection form)
        {
            try
            {
                SQLConnect();
                var repo = new RouteRepository();
                repo.Connection = SQLConnnection;

                if (form["Id_Route"].ToStr() == "")
                {
                    RouteModels RouteCheck = repo.GetSelectedRoute(new string[,] { { "Route", "@Route", form["Route"].ToStr(), "=", "" } });
                    if (RouteCheck.Id_Route == null)
                    {
                        string[,] parameter =
                        {
                            {"Route", "@Route", form["Route"].ToStr()},
                            {"Creation_Date", "@Creation_Date", DateTime.Now.ToStr()}
                        };
                        var Save = repo.InsertRoute(parameter);
                        Response.Cookies["Success"].Value = "Route Data Has Been Saved !";
                    }
                    else
                    {
                        Response.Cookies["Error"].Value = "Route : " + form["Route"].ToStr() + " already exist !";
                    }
                }
                else
                {
                    RouteModels RouteCheck = repo.GetSelectedRoute(new string[,] { { "Route", "@Route", form["Route"].ToStr(), "=", "AND" }, { "Id_Route", "@Id_Route", form["Id_Route"].ToStr(), "<>", "" } });
                    if (RouteCheck.Id_Route == null)
                    {
                        string[] conditions = { "Id_Route" };
                        string[,] parameter =
                        {
                            {"Id_Route", "@Id_Route", form["Id_Route"].ToStr()},
                            {"Route", "@Route", form["Route"].ToStr()},
                            {"Last_Update_Date", "@Last_Update_Date", DateTime.Now.ToStr()}
                        };
                        var Update = repo.UpdateRoute(parameter, conditions);
                        Response.Cookies["Success"].Value = "Route Data Has Been Updated !";
                    }
                    else
                    {
                        Response.Cookies["Error"].Value = "Route : " + form["Route"].ToStr() + " already exist !";
                    }
                }

                SQLDisconnect();
            }
            catch (Exception e)
            {
                Response.Cookies["Error"].Value = e.Message;
                return RedirectToAction("Index", "Route");
            }
            return RedirectToAction("Index", "Route");
        }

        public ActionResult Delete(string id)
        {
            try
            {
                SQLConnect();
                RouteRepository repo = new RouteRepository();
                repo.Connection = SQLConnnection;
                if (repo.DeleteRoute(new string[,] { { "Id_Route", "@Id_Route", id } }) > 0)
                {
                    Response.Cookies["Success"].Value = "Success Delete Route Data !";
                }
                else
                {
                    Response.Cookies["Error"].Value = "Failed Delete Route Data !";
                }
                SQLDisconnect();
            }
            catch (Exception ex)
            {
                Response.Cookies["Error"].Value = ex.Message;
            }

            return RedirectToAction("Index", "Route");
        }

        #endregion
    }
}
