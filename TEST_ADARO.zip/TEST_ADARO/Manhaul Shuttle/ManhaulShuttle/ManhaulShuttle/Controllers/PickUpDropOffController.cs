﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ManhaulShuttle.Models;
using ManhaulShuttle.Repositories;
using ManhaulShuttle.Repositories.PickUpDropOff;
using ManhaulShuttle.Repositories.Route;
using MyDAL;

namespace ManhaulShuttle.Controllers
{
    public class PickUpDropOffController : Controller
    {
        //
        // GET: /PickUpDropOff/

        #region "Settup Connection"

        private DataConnection dCon;
        private DbConnection SQLConnnection;
        private DbTransaction SQLTransaction;

        #region "Connection To SQL Server"

        //========== OPEN CONNECTION TO SQL SERVER ==========//
        //===================================================//

        private void SQLConnect()
        {
            dCon = new DataConnection();
            dCon.Provider = System.Configuration.ConfigurationManager.AppSettings["Provider"];
            dCon.ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"].ToStr();
            if (SQLConnnection != null)
            {
                if (SQLConnnection.State == ConnectionState.Closed)
                {
                    SQLConnnection = dCon.CreateConnection();
                    SQLConnnection.Open();
                }
            }
            else
            {
                SQLConnnection = dCon.CreateConnection();
                SQLConnnection.Open();
            }
        }

        //========== CLOSE CONNECTION TO SQL SERVER =========//
        //===================================================//
        private void SQLDisconnect()
        {
            if (SQLConnnection.State != ConnectionState.Open)
                return;

            SQLConnnection.Close();
            SQLConnnection.Dispose();
        }

        #endregion

        #endregion

        public ActionResult Index()
        {
            SQLConnect();
            List<PickUpDropOffModels> list = new List<PickUpDropOffModels>();
            PickUpDropOffRepository repo = new PickUpDropOffRepository();
            repo.Connection = SQLConnnection;
            list = repo.GetPickUpDropOff(new string[,] { { "", "", "" } });
            SQLDisconnect();
            return View(list);
        }

        public ActionResult PagesPickUpDropOff(string id)
        {
            try
            {
                PickUpDropOffModels dm = new PickUpDropOffModels();
                PickUpDropOffRepository repo = new PickUpDropOffRepository();                

                if (id.ToStr() != "")
                {
                    SQLConnect();
                    repo.Connection = SQLConnnection;
                    dm = repo.GetSelectedPickUpDropOff(new string[,] { { "Id_PickUpDropOff", "@Id_PickUpDropOff", id } });
                    SQLDisconnect();
                }
                dm.RouteList = GetRoute();

                return View(dm);
            }
            catch (Exception ex)
            {
                Response.Cookies["Error"].Value = ex.Message;
                return RedirectToAction("Index", "PickUpDropOff");
            }
        }

        #region "CRUD Pick Up & Drop Off"

        [HttpPost]
        public ActionResult PagesPickUpDropOff(FormCollection form)
        {
            try
            {
                SQLConnect();
                var repo = new PickUpDropOffRepository();
                repo.Connection = SQLConnnection;

                if (form["Id_PickUpDropOff"].ToStr() == "")
                {
                    PickUpDropOffModels PickUpDropOffCheck = repo.GetSelectedPickUpDropOff(new string[,] { { "Id_Route", "@Route", form["Id_Route"].ToStr(), "=", "AND" }, { "PickUpDropOff", "@PickUpDropOff", form["PickUpDropOff"].ToStr(), "=", "" } });
                    if (PickUpDropOffCheck.Id_PickUpDropOff == null)
                    {
                        string[,] parameter =
                        {
                            {"Id_Route", "@Route", form["Id_Route"].ToStr()},
                            {"Time", "@Time", form["datetimepicker"].ToDate().ToString("hh:mm:ss tt", new CultureInfo("en-US"))},
                            {"PickUpDropOff", "@PickUpDropOff", form["PickUpDropOff"].ToStr()},
                            {"Creation_Date", "@Creation_Date", DateTime.Now.ToStr()}
                        };
                        var Save = repo.InsertPickUpDropOff(parameter);
                        Response.Cookies["Success"].Value = "Pick Up & Drop Off Data Has Been Saved !";
                    }
                    else
                    {
                        Response.Cookies["Error"].Value = "Pick Up & Drop Off : " + form["PickUpDropOff"].ToStr() + " already exist !";
                    }
                }
                else
                {
                    PickUpDropOffModels PickUpDropOffCheck = repo.GetSelectedPickUpDropOff(new string[,] { { "Id_Route", "@Route", form["Id_Route"].ToStr(), "=", "AND" }, { "PickUpDropOff", "@PickUpDropOff", form["PickUpDropOff"].ToStr(), "=", "AND" }, { "Id_PickUpDropOff", "@Id_PickUpDropOff", form["Id_PickUpDropOff"].ToStr(), "<>", "" } });
                    if (PickUpDropOffCheck.Id_PickUpDropOff == null)
                    {
                        string[] conditions = { "Id_PickUpDropOff" };
                        string[,] parameter =
                        {
                            {"Id_PickUpDropOff", "@Id_PickUpDropOff", form["Id_PickUpDropOff"].ToStr()},
                            {"Id_Route", "@Route", form["Id_Route"].ToStr()},
                            {"Time", "@Time", form["datetimepicker"].ToDate().ToString("hh:mm:ss tt", new CultureInfo("en-US"))},
                            {"PickUpDropOff", "@PickUpDropOff", form["PickUpDropOff"].ToStr()},
                            {"Last_Update_Date", "@Last_Update_Date", DateTime.Now.ToStr()}
                        };
                        var Update = repo.UpdatePickUpDropOff(parameter, conditions);
                        Response.Cookies["Success"].Value = "Pick Up & Drop Off Data Has Been Updated !";
                    }
                    else
                    {
                        Response.Cookies["Error"].Value = "Pick Up & Drop Off : " + form["PickUpDropOff"].ToStr() + " already exist !";
                    }
                }

                SQLDisconnect();
            }
            catch (Exception e)
            {
                Response.Cookies["Error"].Value = e.Message;
                return RedirectToAction("Index", "PickUpDropOff");
            }
            return RedirectToAction("Index", "PickUpDropOff");
        }

        public ActionResult Delete(string id)
        {
            try
            {
                SQLConnect();
                PickUpDropOffRepository repo = new PickUpDropOffRepository();
                repo.Connection = SQLConnnection;
                if (repo.DeletePickUpDropOff(new string[,] { { "Id_PickUpDropOff", "@Id_PickUpDropOff", id } }) > 0)
                {
                    Response.Cookies["Success"].Value = "Success Delete Pick Up & Drop Off Data !";
                }
                else
                {
                    Response.Cookies["Error"].Value = "Failed Delete Pick Up & Drop Off Data !";
                }
                SQLDisconnect();
            }
            catch (Exception ex)
            {
                Response.Cookies["Error"].Value = ex.Message;
            }

            return RedirectToAction("Index", "PickUpDropOff");
        }

        #endregion

        #region "GET ROUTE"
        public List<RouteModels> GetRoute()
        {
            SQLConnect();
            List<RouteModels> list = new List<RouteModels>();
            RouteRepository rRepo = new RouteRepository();

            rRepo.Connection = SQLConnnection;
            list = rRepo.GetRoute(new string[,] { { "", "", "" } });
            SQLDisconnect();
            return list;
        }
        #endregion
    }
}
