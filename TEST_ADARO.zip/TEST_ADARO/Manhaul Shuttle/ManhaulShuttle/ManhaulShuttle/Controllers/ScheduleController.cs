﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ManhaulShuttle.Models;
using ManhaulShuttle.Repositories;
using ManhaulShuttle.Repositories.Department;
using ManhaulShuttle.Repositories.PickUpDropOff;
using ManhaulShuttle.Repositories.Route;
using ManhaulShuttle.Repositories.Schedule;
using MyDAL;

namespace ManhaulShuttle.Controllers
{
    public class ScheduleController : Controller
    {
        //
        // GET: /Schedule/

        #region "Settup Connection"

        private DataConnection dCon;
        private DbConnection SQLConnnection;
        private DbTransaction SQLTransaction;

        #region "Connection To SQL Server"

        //========== OPEN CONNECTION TO SQL SERVER ==========//
        //===================================================//

        private void SQLConnect()
        {
            dCon = new DataConnection();
            dCon.Provider = System.Configuration.ConfigurationManager.AppSettings["Provider"];
            dCon.ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"].ToStr();
            if (SQLConnnection != null)
            {
                if (SQLConnnection.State == ConnectionState.Closed)
                {
                    SQLConnnection = dCon.CreateConnection();
                    SQLConnnection.Open();
                }
            }
            else
            {
                SQLConnnection = dCon.CreateConnection();
                SQLConnnection.Open();
            }
        }

        //========== CLOSE CONNECTION TO SQL SERVER =========//
        //===================================================//
        private void SQLDisconnect()
        {
            if (SQLConnnection.State != ConnectionState.Open)
                return;

            SQLConnnection.Close();
            SQLConnnection.Dispose();
        }

        #endregion

        #endregion

        public ActionResult Index()
        {
            SQLConnect();
            List<ScheduleModels> list = new List<ScheduleModels>();
            ScheduleRepository repo = new ScheduleRepository();
            repo.Connection = SQLConnnection;
            list = repo.GetSchedule(new string[,] { { "", "", "" } });
            SQLDisconnect();
            return View(list);
        }

        public ActionResult PagesSchedule(string id)
        {
            try
            {
                ScheduleModels dm = new ScheduleModels();
                ScheduleRepository repo = new ScheduleRepository();

                if (id.ToStr() != "")
                {
                    SQLConnect();
                    repo.Connection = SQLConnnection;
                    dm = repo.GetSelectedSchedule(new string[,] { { "s.Id_Schedule", "@Id_Schedule", id } });
                    SQLDisconnect();
                }
                dm.RouteList = GetRoute();
                dm.DepartmentList = GetDepartment();

                return View(dm);
            }
            catch (Exception ex)
            {
                Response.Cookies["Error"].Value = ex.Message;
                return RedirectToAction("Index", "Schedule");
            }
        }

        #region "CRUD Pick Up & Drop Off"

        [HttpPost]
        public ActionResult PagesSchedule(FormCollection form)
        {
            try
            {
                SQLConnect();
                var repo = new ScheduleRepository();
                repo.Connection = SQLConnnection;

                if (form["Id_Schedule"].ToStr() == "")
                {
                    ScheduleModels ScheduleCheck = repo.GetSelectedSchedule(new string[,] { { "s.Id_Route", "@Route", form["Id_Route"].ToStr(), "=", "AND" }, { "s.Time", "@Time", form["Time"].ToStr(), "=", "AND" }, { "s.Name", "@Name", form["Name"].ToStr(), "=", "AND" }, { "s.Id_Department", "@Id_Department", form["Id_Department"].ToStr(), "=", "AND" }, { "s.Id_PickUp", "@Id_PickUp", form["Id_PickUp"].ToStr(), "=", "AND" }, { "s.Id_DropOff", "@Id_DropOff", form["Id_DropOff"].ToStr(), "=", "" } });
                    if (ScheduleCheck.Id_Schedule == null)
                    {
                        string[,] parameter =
                        {
                            {"Id_Route", "@Route", form["Id_Route"].ToStr()},
                            {"Time", "@Time", form["datetimepicker"].ToDate().ToString("hh:mm:ss tt", new CultureInfo("en-US"))},
                            {"Name", "@Name", form["Name"].ToStr()},
                            {"Id_Department", "@Id_Department", form["Id_Department"].ToStr()},
                            {"Id_PickUp", "@Id_PickUp", form["Id_PickUp"].ToStr()},
                            {"Id_DropOff", "@Id_DropOff", form["Id_DropOff"].ToStr()},
                            {"Creation_Date", "@Creation_Date", DateTime.Now.ToStr()}
                        };
                        var Save = repo.InsertSchedule(parameter);
                        Response.Cookies["Success"].Value = "Schedule Data Has Been Saved !";
                    }
                    else
                    {
                        Response.Cookies["Error"].Value = "Schedule : " + form["Name"].ToStr() + " already exist !";
                    }
                }
                else
                {
                    ScheduleModels ScheduleCheck = repo.GetSelectedSchedule(new string[,] { { "s.Id_Route", "@Route", form["Id_Route"].ToStr(), "=", "AND" }, { "s.Time", "@Time", form["Time"].ToStr(), "=", "AND" }, { "s.Name", "@Name", form["Name"].ToStr(), "=", "AND" }, { "s.Id_Department", "@Id_Department", form["Id_Department"].ToStr(), "=", "AND" }, { "s.Id_PickUp", "@Id_PickUp", form["Id_PickUp"].ToStr(), "=", "AND" }, { "s.Id_DropOff", "@Id_DropOff", form["Id_DropOff"].ToStr(), "=", "AND" }, { "s.Id_Schedule", "@Id_Schedule", form["Id_Schedule"].ToStr(), "<>", "" } });
                    if (ScheduleCheck.Id_Schedule == null)
                    {
                        string[] conditions = { "Id_Schedule" };
                        string[,] parameter =
                        {
                            {"Id_Schedule", "@Id_Schedule", form["Id_Schedule"].ToStr()},
                            {"Id_Route", "@Route", form["Id_Route"].ToStr()},
                            {"Time", "@Time", form["datetimepicker"].ToDate().ToString("hh:mm:ss tt", new CultureInfo("en-US"))},
                            {"Name", "@Name", form["Name"].ToStr()},
                            {"Id_Department", "@Id_Department", form["Id_Department"].ToStr()},
                            {"Id_PickUp", "@Id_PickUp", form["Id_PickUp"].ToStr()},
                            {"Id_DropOff", "@Id_DropOff", form["Id_DropOff"].ToStr()},
                            {"Last_Update_Date", "@Last_Update_Date", DateTime.Now.ToStr()}
                        };
                        var Update = repo.UpdateSchedule(parameter, conditions);
                        Response.Cookies["Success"].Value = "Schedule Data Has Been Updated !";
                    }
                    else
                    {
                        Response.Cookies["Error"].Value = "Schedule : " + form["Name"].ToStr() + " already exist !";
                    }
                }

                SQLDisconnect();
            }
            catch (Exception e)
            {
                Response.Cookies["Error"].Value = e.Message;
                return RedirectToAction("Index", "Schedule");
            }
            return RedirectToAction("Index", "Schedule");
        }

        public ActionResult Delete(string id)
        {
            try
            {
                SQLConnect();
                ScheduleRepository repo = new ScheduleRepository();
                repo.Connection = SQLConnnection;
                if (repo.DeleteSchedule(new string[,] { { "Id_Schedule", "@Id_Schedule", id } }) > 0)
                {
                    Response.Cookies["Success"].Value = "Success Delete Schedule Data !";
                }
                else
                {
                    Response.Cookies["Error"].Value = "Failed Delete Schedule Data !";
                }
                SQLDisconnect();
            }
            catch (Exception ex)
            {
                Response.Cookies["Error"].Value = ex.Message;
            }

            return RedirectToAction("Index", "Schedule");
        }

        #endregion

        #region "GET ROUTE"
        public List<RouteModels> GetRoute()
        {
            SQLConnect();
            List<RouteModels> list = new List<RouteModels>();
            RouteRepository rRepo = new RouteRepository();

            rRepo.Connection = SQLConnnection;
            list = rRepo.GetRoute(new string[,] { { "", "", "" } });
            SQLDisconnect();
            return list;
        }
        #endregion

        #region "GET DEPARTMENT"
        public List<DepartmentModels> GetDepartment()
        {
            SQLConnect();
            List<DepartmentModels> list = new List<DepartmentModels>();
            DepartmentRepository rRepo = new DepartmentRepository();

            rRepo.Connection = SQLConnnection;
            list = rRepo.GetDepartment(new string[,] { { "", "", "" } });
            SQLDisconnect();
            return list;
        }
        #endregion

        #region "GET PICK UP & DROP OFF, TIME"
        public JsonResult ListPickUpDropOffTime(string id)
        {
            SQLConnect();
            var list = new List<PickUpDropOffModels>();
            var bRepo = new PickUpDropOffRepository();

            bRepo.Connection = SQLConnnection;
            list = bRepo.GetPickUpDropOff(new string[,] { { "p.Id_Route", "@id", id } });
            SQLDisconnect();
            return Json(list, JsonRequestBehavior.AllowGet);
        }
        #endregion
    }
}
