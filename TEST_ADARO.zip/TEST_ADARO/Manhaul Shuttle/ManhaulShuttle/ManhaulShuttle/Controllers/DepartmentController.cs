﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ManhaulShuttle.Models;
using ManhaulShuttle.Repositories.Department;
using MyDAL;

namespace ManhaulShuttle.Controllers
{
    public class DepartmentController : Controller
    {
        //
        // GET: /Department/

        #region "Settup Connection"

        private DataConnection dCon;
        private DbConnection SQLConnnection;
        private DbTransaction SQLTransaction;

        #region "Connection To SQL Server"

        //========== OPEN CONNECTION TO SQL SERVER ==========//
        //===================================================//

        private void SQLConnect()
        {
            dCon = new DataConnection();
            dCon.Provider = System.Configuration.ConfigurationManager.AppSettings["Provider"];
            dCon.ConnectionString = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"].ToStr();
            if (SQLConnnection != null)
            {
                if (SQLConnnection.State == ConnectionState.Closed)
                {
                    SQLConnnection = dCon.CreateConnection();
                    SQLConnnection.Open();
                }
            }
            else
            {
                SQLConnnection = dCon.CreateConnection();
                SQLConnnection.Open();
            }
        }

        //========== CLOSE CONNECTION TO SQL SERVER =========//
        //===================================================//
        private void SQLDisconnect()
        {
            if (SQLConnnection.State != ConnectionState.Open)
                return;

            SQLConnnection.Close();
            SQLConnnection.Dispose();
        }

        #endregion

        #endregion

        public ActionResult Index()
        {
            SQLConnect();
            List<DepartmentModels> list = new List<DepartmentModels>();
            DepartmentRepository repo = new DepartmentRepository();
            repo.Connection = SQLConnnection;
            list = repo.GetDepartment(new string[,] { { "", "", "" } });
            SQLDisconnect();
            return View(list);
        }

        public ActionResult PagesDepartment(string id)
        {
            try
            {
                DepartmentModels dm = new DepartmentModels();
                DepartmentRepository repo = new DepartmentRepository();

                if (id.ToStr() != "")
                {
                    SQLConnect();
                    repo.Connection = SQLConnnection;
                    dm = repo.GetSelectedDepartment(new string[,] { { "Id_Department", "@Id_Department", id } });
                    SQLDisconnect();
                }

                return View(dm);
            }
            catch (Exception ex)
            {
                Response.Cookies["Error"].Value = ex.Message;
                return RedirectToAction("Index", "Department");
            }
        }

        #region "CRUD DEPARTMENT"

        [HttpPost]
        public ActionResult PagesDepartment(FormCollection form)
        {
            try
            {
                SQLConnect();
                var repo = new DepartmentRepository();
                repo.Connection = SQLConnnection;

                if (form["Id_Department"].ToStr() == "")
                {
                    DepartmentModels DepartmentCheck = repo.GetSelectedDepartment(new string[,] { { "Department", "@Department", form["Department"].ToStr(), "=", "" } });
                    if (DepartmentCheck.Id_Department == null)
                    {
                        string[,] parameter =
                        {
                            {"Department", "@Department", form["Department"].ToStr()},
                            {"Creation_Date", "@Creation_Date", DateTime.Now.ToStr()}
                        };
                        var Save = repo.InsertDepartment(parameter);
                        Response.Cookies["Success"].Value = "Department Data Has Been Saved !";
                    }
                    else
                    {
                        Response.Cookies["Error"].Value = "Department : " + form["Department"].ToStr() + " already exist !";
                    }
                }
                else
                {
                    DepartmentModels DepartmentCheck = repo.GetSelectedDepartment(new string[,] { { "Department", "@Department", form["Department"].ToStr(), "=", "AND" }, { "Id_Department", "@Id_Department", form["Id_Department"].ToStr(), "<>", "" } });
                    if (DepartmentCheck.Id_Department == null)
                    {
                        string[] conditions = { "Id_Department" };
                        string[,] parameter =
                        {
                            {"Id_Department", "@Id_Department", form["Id_Department"].ToStr()},
                            {"Department", "@Department", form["Department"].ToStr()},
                            {"Last_Update_Date", "@Last_Update_Date", DateTime.Now.ToStr()}
                        };
                        var Update = repo.UpdateDepartment(parameter, conditions);
                        Response.Cookies["Success"].Value = "Department Data Has Been Updated !";
                    }
                    else
                    {
                        Response.Cookies["Error"].Value = "Department : " + form["Department"].ToStr() + " already exist !";
                    }
                }

                SQLDisconnect();
            }
            catch (Exception e)
            {
                Response.Cookies["Error"].Value = e.Message;
                return RedirectToAction("Index", "Department");
            }
            return RedirectToAction("Index", "Department");
        }

        public ActionResult Delete(string id)
        {
            try
            {
                SQLConnect();
                DepartmentRepository repo = new DepartmentRepository();
                repo.Connection = SQLConnnection;
                if (repo.DeleteDepartment(new string[,] { { "Id_Department", "@Id_Department", id } }) > 0)
                {
                    Response.Cookies["Success"].Value = "Success Delete Department Data !";
                }
                else
                {
                    Response.Cookies["Error"].Value = "Failed Delete Department Data !";
                }
                SQLDisconnect();
            }
            catch (Exception ex)
            {
                Response.Cookies["Error"].Value = ex.Message;
            }

            return RedirectToAction("Index", "Department");
        }

        #endregion
    }
}
