﻿using System.Web;
using System.Web.Mvc;

namespace ManhaulShuttle
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}