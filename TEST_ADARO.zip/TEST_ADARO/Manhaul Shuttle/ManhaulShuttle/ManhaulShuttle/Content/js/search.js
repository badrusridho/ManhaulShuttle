﻿var options = {
    valueNames: ['Unit_Name', 'Unit_Brand']
};

var userList = new List('unit_list', options);

