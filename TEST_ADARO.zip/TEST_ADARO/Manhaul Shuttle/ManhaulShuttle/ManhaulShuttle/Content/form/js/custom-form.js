﻿//Form HRDBlacklist for Condition & Validation 
$(document).ready(function() {
    $("#employeeNameTxt").css("display", "none");
    $("#employeeNameTxt").attr("readonly", "readonly");
    $("#GenderList").attr("readonly", "readonly");

    $("#GroupCandidateID").css("display", "none");
    $("#datetimepicker1").css("display", "none");
});

$("#sourcing").change(function() {
    var source = $("#sourcing").val();
    $("input[type=text]").val("");
    if (source == "employee") {
        $("#groupUnit").css("display", "");
        $("#employeeName").css("display", "");
        $("#employeeName").removeAttr("readonly");
        $("#employeeNameTxt").attr("readonly", "readonly");
        $("#s2id_employeeName").css("display", "");
        $("#employeeNameTxt").css("display", "none");
        $("#employeeNameTxt").attr("readonly", "readonly");
        $("#Gender").attr("readonly", "readonly");
        $("#EmployeeID").attr("readonly", "readonly");
        $("#datetimepicker1").attr("readonly", "readonly");
        $("#datetimepicker1").css("display", "");
        $("#dobDate").css("display", "none");
        $("#address").attr("readonly", "readonly");
        $("#nationalID").attr("readonly", "readonly");
        $("#education").attr("readonly", "readonly");
        $("#institution").attr("readonly", "readonly");
        $("#position").attr("readonly", "readonly");
        $("#GroupCandidateID").css("display", "none");
        $("#EmployeeIdLabel").text("Employee ID");
        $("#GenderList").attr("readonly", "readonly");
        $("#labelName").text("Employee Name");
        $("#resign_date").attr("readonly", "readonly");
        $("#resign_reason").attr("readonly", "readonly");
        $("#containerResignDate").css("display", "");
        $("#containerResignReason").css("display", "");
        $("#groupCompany").css("display", "none");
    } else {
        if (source == "candidate") {
            $("#EmployeeIdLabel").text("Candidate ID");
            $("#GroupCandidateID").css("display", "");
            $("#Gender").css("display", "none");
            $("#datetimepicker1").css("display", "none");
            $("#employeeNameTxt").css("display", "");
            $("#groupCompany").css("display", "none");
        } else {
            $("#GroupCandidateID").css("display", "none");
            $("#Gender").css("display", "none");
            $("#datetimepicker1").css("display", "none");
            $("#groupCompany").css("display", "");
        }
        $("#containerResignDate").css("display", "none");
        $("#containerResignReason").css("display", "none");
        $("#resign_date").removeAttr("readonly");
        $("#resign_reason").removeAttr("readonly");
        $("#labelName").text("Name");
        $("#GenderList").removeAttr("readonly");
        $("#GenderList").removeAttr("readonly");
        $("#address").removeAttr("readonly");
        $("#dobDate").css("display", "");
        $("#datetimepicker1").css("display", "none");
        $("#dobDate").removeAttr("readonly");
        $("#s2id_employeeName").css("display", "none");
        $("#nationalID").removeAttr("readonly");
        $("#education").removeAttr("readonly");
        $("#institution").removeAttr("readonly");
        $("#position").removeAttr("readonly");
        $(".select2-chosen").text("");
        $("#groupUnit").css("display", "none");
        $("#employeeName").attr("readonly", "readonly");
        $("#employeeName").css("display", "none");
        $("#employeeName").empty();
        $("#employeeNameTxt").css("display", "");
        $("#employeeNameTxt").removeAttr("readonly");
        $("#Gender").css("display", "none");
        $("#Gender").attr("readonly", "readonly");
        $("#GenderList").css("display", "");
        $("#EmployeeID").removeAttr("readonly");
        $("#datetimepicker1").css("display", "none");
    }
});



//$("#SubmitGlasses").click(function () {
//    var flag = true;
//    if ($("#employeeName").val() == null || $("#employeeName").val() == "" || $("#employeeName").val() == "0") {
//        $("#alert_employeeName").css("display", "");
//        $("#employeeName").css("border-color", "#D50000");
//        flag = false;
//    } else {
//        $("#alert_employeeName").css("display", "none");
//        $("#employeeName").css("border-color", "#0D47A1");
//    }
//});