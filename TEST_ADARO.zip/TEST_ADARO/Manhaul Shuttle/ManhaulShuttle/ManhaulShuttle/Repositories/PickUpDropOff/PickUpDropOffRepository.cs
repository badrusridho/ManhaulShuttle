﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web;
using ManhaulShuttle.Models;
using MyDAL;

namespace ManhaulShuttle.Repositories.PickUpDropOff
{
    public class PickUpDropOffRepository : DataAccess
    {
        DataTable dt = new DataTable();
        private string QueryString = "";
        private string WhereCondition = "";

        public PickUpDropOffRepository()
        {
            Provider = System.Configuration.ConfigurationManager.AppSettings["Provider"];
            TableName = "PickUpDropOff";
        }

        public List<PickUpDropOffModels> GetPickUpDropOff(string[,] parameter)
        {
            List<PickUpDropOffModels> list = new List<PickUpDropOffModels>();
            WhereCondition = parameter.ToCondition();
            dt = READ("SELECT p.Id_PickUpDropOff, p.Id_Route, ltrim(right(convert(varchar(25), p.Time, 100), 7)) AS Time, P.PickUpDropOff, r.Route FROM PickUpDropOff p INNER JOIN Route r ON r.Id_Route = p.Id_Route" + (WhereCondition == "" ? "" : " WHERE " + WhereCondition), parameter);
            foreach (DataRow dr in dt.Rows)
            {
                PickUpDropOffModels pdo = new PickUpDropOffModels();
                pdo.Id_PickUpDropOff = dr["Id_PickUpDropOff"].ToStr();
                pdo.Id_Route = dr["Id_Route"].ToStr();
                pdo.Time = dt.Rows[0]["Time"].ToStr();
                pdo.PickUpDropOff = dr["PickUpDropOff"].ToStr();
                pdo.Route = dr["Route"].ToStr();
                list.Add(pdo);
            }
            return list;
        }

        public PickUpDropOffModels GetSelectedPickUpDropOff(string[,] parameters)
        {
            PickUpDropOffModels pdo = new PickUpDropOffModels();
            WhereCondition = parameters.ToCondition();
            dt = READ("SELECT Id_PickUpDropOff, Id_Route, ltrim(right(convert(varchar(25), Time, 100), 7)) AS Time, PickUpDropOff FROM PickUpDropOff " + (WhereCondition != "" ? " WHERE " + WhereCondition : ""), parameters);
            if (dt.Rows.Count > 0)
            {
                pdo.Id_PickUpDropOff = dt.Rows[0]["Id_PickUpDropOff"].ToStr();
                pdo.Id_Route = dt.Rows[0]["Id_Route"].ToStr();
                pdo.Time = dt.Rows[0]["Time"].ToStr();
                pdo.PickUpDropOff = dt.Rows[0]["PickUpDropOff"].ToStr();
            }
            return pdo;
        }

        public long InsertPickUpDropOff(string[,] parameter)
        {
            TableName = "PickUpDropOff";
            return CREATE(parameter);
        }

        public long UpdatePickUpDropOff(string[,] parameter, string[] conditions)
        {
            TableName = "PickUpDropOff";
            return UPDATE(parameter, conditions);
        }

        public long DeletePickUpDropOff(string[,] parameters)
        {
            TableName = "PickUpDropOff";
            return DELETE(parameters);
        }
    }
}