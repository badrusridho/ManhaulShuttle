﻿using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Configuration;
using System.Net;
using System.IO;
using System.Text;
using System.Web.Script.Serialization;
using System.Xml.Serialization;

namespace ManhaulShuttle.Repositories
{
    public static class ExtentionMethods
    {
        /// <summary>
        /// Fungsi untuk mengubah variable menjadi tipe integer
        /// </summary>
        public static int ToInt(this object value)
        {
            if (value == null || value.ToString() == "")
            {
                return 0;
            }
            return Convert.ToInt32(value);
        }

        /// <summary>
        /// Fungsi untuk mengubah variable menjadi tipe string
        /// </summary>
        public static string Tostr(this object value)
        {
            if (value == null || value.ToString() == "")
            {
                return "";
            }
            return Convert.ToString(value).Trim();
        }

        public static string ToSeoUrl(this string url)
        {
            // make the url lowercase
            string encodedUrl = (url ?? "").ToLower();

            // remove characters
            encodedUrl = encodedUrl.Replace("#", "sharp");

            // replace & with and
            encodedUrl = Regex.Replace(encodedUrl, @"\&+", "and");

            // remove characters
            encodedUrl = encodedUrl.Replace("'", "");

            // remove invalid characters
            encodedUrl = Regex.Replace(encodedUrl, @"[^a-z0-9]", "-");

            // remove duplicates
            encodedUrl = Regex.Replace(encodedUrl, @"-+", "-");

            // trim leading & trailing characters
            encodedUrl = encodedUrl.Trim('-');

            return encodedUrl;
        }

        /// <summary>
        /// Fungsi untuk mengubah variable menjadi tipe boolean
        /// </summary>
        public static bool ToBool(this object value)
        {
            if (value == null || value.ToString() == "")
            {
                return false;
            }
            return Convert.ToBoolean(value);
        }

        /// <summary>
        /// Fungsi untuk mengubah variable menjadi tipe date
        /// </summary>
        public static DateTime ToDate(this object value)
        {
            if (value == null || value.ToString() == "")
            {
                return DateTime.MinValue;
            }

            try
            {
                return Convert.ToDateTime(value);
            }
            catch
            {
                return DateTime.MinValue;
            }
        }

        /// <summary>
        /// Fungsi untuk mengubah variable menjadi tipe double
        /// </summary>
        public static double ToDouble(this object value)
        {
            if (value == null || value.ToString() == "")
            {
                return 0;
            }
            return Convert.ToDouble(value);
        }

        /// <summary>
        /// Fungsi mengecek apakah variable berupa angka
        /// </summary>
        public static bool IsNumeric(this string strVal)
        {
            var reg = new Regex("[^0-9-]");
            var reg2 = new Regex("^-[0-9]+$|^[0-9]+$");
            return (!reg.IsMatch(strVal) && reg2.IsMatch(strVal));
        }

        /// <summary>
        /// Fungsi mengecek apakah format email benar
        /// </summary>
        public static bool IsValidEmail(this string value)
        {
            string strRegex = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
                              @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
                              @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";

            var re = new Regex(strRegex);

            return re.IsMatch(value);
        }

        /// <summary>
        /// Fungsi untuk memvalidasi tanggal
        /// </summary>
        public static bool ValidateDate(this string date)
        {
            try
            {
                // for US, alter to suit if splitting on hyphen, comma, etc.
                string[] dateParts = date.Split('/');

                // create new date from the parts; if this does not fail
                // the method will return true and the date is valid
                var testDate = new
                                    DateTime(Convert.ToInt32(dateParts[2]),
                                    Convert.ToInt32(dateParts[0]),
                                    Convert.ToInt32(dateParts[1]));
                return true;
            }
            catch
            {
                // if a test date cannot be created, the
                // method will return false
                return false;
            }
        }

        /// <summary>
        /// Fungsi untuk membandingkan tanggal
        /// </summary>
        public static int CompareDate(this DateTime FirstDate, DateTime SecondDate)
        {
            var dt1 = FirstDate;
            var dt2 = SecondDate;

            var date1 = new DateTime(dt1.Year, dt1.Month, dt1.Day);
            var date2 = new DateTime(dt2.Year, dt2.Month, dt2.Day);
            int result = DateTime.Compare(date1, date2);

            return result;
        }

        /// <summary>
        /// Fungsi untuk mengecek security input
        /// </summary>
        public static String CekSecurity(this String cek)
        {

            String[,] injeksi = new String[,]{
        
            {"<script>","script"},
            {"</script>",""},
            {"-",""},
            {"'",""},
            {";",""},
            {"#",""},
            {"&","and"},
            {"%",""},
            {"EXEC",""},
            {"OR",""},
            {"*",""},
            {"=",""},
            {"/**/",""},
            {"/*",""},
            {"/",""},
            {"--",""},
            {Convert.ToChar(92).ToString(),""},
            {"<",""},
            {">",""},
            {"(",""},
            {")",""},
            {"CHAR(",""},
            {"&#92;",""},
            {"&#61;",""}
           
        };

            for (int i = 0; i <= injeksi.GetUpperBound(0); i++)
            {

                if (cek.IndexOf(injeksi[i, 0]) != -1)
                {
                    cek = cek.Replace(injeksi[i, 0], injeksi[i, 1]);
                }

            }

            return cek;
        }

        public static string GetPageName(this string url)
        {
            string sPath = url;
            System.IO.FileInfo oInfo = new System.IO.FileInfo(sPath);
            string sRet = oInfo.Name;
            return sRet;
        }

        public static string sha256_hash(String value)
        {
            using (SHA256 hash = SHA256Managed.Create())
            {
                return string.Join("", hash
                  .ComputeHash(Encoding.UTF8.GetBytes(value))
                  .Select(item => item.ToString("x2")));
            }
        }

        public static string CalculateMD5Hash(this string input)
        {

            // step 1, calculate MD5 hash from input

            MD5 md5 = System.Security.Cryptography.MD5.Create();

            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);

            byte[] hash = md5.ComputeHash(inputBytes);

            // step 2, convert byte array to hex string

            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < hash.Length; i++)
            {

                sb.Append(hash[i].ToString("X2"));

            }

            return sb.ToString();

        }

        /// <summary>
        /// Get MD5 string of string
        /// </summary>

        public static string Encrypt(this string ValueToEncrypt)
        {
            bool useHashing = true;
            byte[] keyArray;
            byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(ValueToEncrypt);

            System.Configuration.AppSettingsReader settingsReader = new AppSettingsReader();
            // Get the key from config file
            string key = "789ABC123DEF456HIJ";
            //System.Windows.Forms.MessageBox.Show(key);
            if (useHashing)
            {
                MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
                keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));
                hashmd5.Clear();
            }
            else
                keyArray = UTF8Encoding.UTF8.GetBytes(key);

            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
            tdes.Key = keyArray;
            tdes.Mode = CipherMode.ECB;
            tdes.Padding = PaddingMode.PKCS7;

            ICryptoTransform cTransform = tdes.CreateEncryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
            tdes.Clear();
            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }
        /// <summary>
        /// DeCrypt a string using dual encryption method. Return a DeCrypted clear string
        /// </summary>
        /// <param name="cipherString">encrypted string</param>
        /// <param name="useHashing">Did you use hashing to encrypt this data? pass true is yes</param>
        /// <returns></returns>
        public static string Decrypt(this string ValueToDecript)
        {
            bool useHashing = true;
            byte[] keyArray;
            byte[] toEncryptArray = Convert.FromBase64String(ValueToDecript);

            System.Configuration.AppSettingsReader settingsReader = new AppSettingsReader();
            //Get your key from config file to open the lock!
            string key = "789ABC123DEF456HIJ"; ;

            SHA256CryptoServiceProvider sha = new SHA256CryptoServiceProvider();
            keyArray = sha.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));

            if (useHashing)
            {
                MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
                keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));
                hashmd5.Clear();
            }
            else
                keyArray = UTF8Encoding.UTF8.GetBytes(key);

            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
            tdes.Key = keyArray;
            tdes.Mode = CipherMode.ECB;
            tdes.Padding = PaddingMode.PKCS7;

            ICryptoTransform cTransform = tdes.CreateDecryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);

            tdes.Clear();
            return UTF8Encoding.UTF8.GetString(resultArray);
        }

        public static string Terbilang(this int x)
        {

            string[] bilangan = { "", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas" };
            string temp = "";

            if (x < 12)
            {
                temp = " " + bilangan[x];
            }
            else if (x < 20)
            {
                temp = Terbilang(x - 10).ToString() + " belas";
            }
            else if (x < 100)
            {
                temp = Terbilang(x / 10) + " puluh" + Terbilang(x % 10);
            }
            else if (x < 200)
            {
                temp = " seratus" + Terbilang(x - 100);
            }
            else if (x < 1000)
            {
                temp = Terbilang(x / 100) + " ratus" + Terbilang(x % 100);
            }
            else if (x < 2000)
            {
                temp = " seribu" + Terbilang(x - 1000);
            }
            else if (x < 1000000)
            {
                temp = Terbilang(x / 1000) + " ribu" + Terbilang(x % 1000);
            }
            else if (x < 1000000000)
            {
                temp = Terbilang(x / 1000000) + " juta" + Terbilang(x % 1000000);
            }
            return temp.First().ToString().ToUpper() + String.Join("", temp.Skip(1));
        }

        public static string GetRandomString(this int seed)
        {
            //use the following string to control your set of alphabetic characters to choose from
            //for example, you could include uppercase too
            const string alphabet = "QAZ1WSX2EDC3RFV4TGB5YHN6UJM7IK8OL9P0";

            // Random is not truly random,
            // so we try to encourage better randomness by always changing the seed value
            var rnd = new Random((seed + DateTime.Now.Millisecond));

            // basic 5 digit random number
            string result = rnd.Next(100000, 999999).ToString();


            // single random character in ascii range a-z
            int alphLength = rnd.Next(0, alphabet.Length - 1);
            string alphaChar = alphabet.Substring(alphLength, 1);


            // random position to put the alpha character
            int replacementIndex = rnd.Next(0, (result.Length - 1));
            result = result.Remove(replacementIndex, 1).Insert(replacementIndex, alphaChar);


            return result;
        }

        public static byte[] GetFileData(this string fileName, string filePath)
        {
            var fullFilePath = string.Format("{0}/{1}", filePath, fileName);
            if (!File.Exists(fullFilePath))
                throw new FileNotFoundException("The file does not exist.", fullFilePath);
            return File.ReadAllBytes(fullFilePath);
        }

        public static string ToEncrypt(this string toEncrypt, bool useHashing)
        {
            byte[] keyArray;
            byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(toEncrypt);

            System.Configuration.AppSettingsReader settingsReader = new AppSettingsReader();
            // Get the key from config file
            //string key = (string)settingsReader.GetValue("SecurityKey", typeof(String));
            //System.Windows.Forms.MessageBox.Show(key);
            string key = "789ABC123DEF456HIJ";
            if (useHashing)
            {
                MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
                keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));
                hashmd5.Clear();
            }
            else
                keyArray = UTF8Encoding.UTF8.GetBytes(key);

            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
            tdes.Key = keyArray;
            tdes.Mode = CipherMode.CBC;
            tdes.Padding = PaddingMode.ANSIX923;

            ICryptoTransform cTransform = tdes.CreateEncryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
            tdes.Clear();
            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }
        /// <summary>
        /// DeCrypt a string using dual encryption method. Return a DeCrypted clear string
        /// </summary>
        /// <param name="cipherString">encrypted string</param>
        /// <param name="useHashing">Did you use hashing to encrypt this data? pass true is yes</param>
        /// <returns></returns>
        public static string ToDecrypt(this string cipherString, bool useHashing)
        {
            byte[] keyArray;
            byte[] toEncryptArray = Convert.FromBase64String(cipherString);

            System.Configuration.AppSettingsReader settingsReader = new AppSettingsReader();
            //Get your key from config file to open the lock!
            //string key = (string)settingsReader.GetValue("SecurityKey", typeof(String));
            string key = "789ABC123DEF456HIJ";
            if (useHashing)
            {
                MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
                keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));
                hashmd5.Clear();
            }
            else
                keyArray = UTF8Encoding.UTF8.GetBytes(key);

            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
            tdes.Key = keyArray;
            tdes.Mode = CipherMode.CBC;
            tdes.Padding = PaddingMode.ANSIX923;

            ICryptoTransform cTransform = tdes.CreateDecryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);

            tdes.Clear();
            return UTF8Encoding.UTF8.GetString(resultArray);
        }

        /// <summary>
        /// Function to check is string a correct excel formulas
        /// </summary>

        public static bool ValidateArithmaticFormula(this string expression)
        {
            int previous = 0;
            int previous1 = 0;
            string expEvaluated = string.Empty;
            int operatorOperand = 1;
            for (int i = 0; i < expression.Length; i++)
            {
                char c = expression[i];
                if (c == ')')
                {
                }
                else if (c == '(')
                {
                    int j = expression.IndexOf(')', i);
                    if (j == -1)
                        return false;
                    string substring = expression.Substring(i + 1, j - i - 1);
                    while (getcharactercount(substring, '(') != getcharactercount(substring, ')'))
                    {
                        if (j < expression.Length - 1)
                            j = expression.IndexOf(')', j + 1);
                        else
                            break;
                        substring = expression.Substring(i + 1, j - i - 1);
                    } i = j - 1; //Changing the counter i to point to the next character                   
                    //validating the sub expression                   
                    if (ValidateArithmaticFormula(substring) == true)
                    {
                        if (previous != 0 && previous1 != 0 && previous > previous1)
                        {
                            previous1 = operatorOperand;
                            operatorOperand++;
                            previous = 0;
                        }
                        else if (previous != 0 && previous1 != 0 && previous <= previous1)
                        {
                            return false;
                        }
                        else if (previous1 != 0)
                        {
                            return false;
                        }
                        else
                        {
                            previous1 = operatorOperand;
                            operatorOperand++;
                        }
                    }
                    else
                    {
                        return false;
                    }
                }
                else if (c == '+' || c == '-' || c == '*' || c == '/')
                {
                    if (previous != 0)
                    {
                        return false;
                    }
                    previous = operatorOperand;
                    operatorOperand++;
                }
                else
                {
                    if (previous != 0 && previous1 != 0 && previous > previous1)
                    {
                        previous1 = operatorOperand;
                        operatorOperand++;
                        previous = 0;
                    }
                    else if (previous != 0 && previous1 != 0 && previous <= previous1)
                    {
                        return false;
                    }
                    else if (previous1 != 0)
                    {
                        return false;
                    }
                    else
                    {
                        previous1 = operatorOperand;
                        operatorOperand++;
                    }
                }
            }
            if (previous != 0)
                return false;
            return true;
        }


        private static int getcharactercount(string exp, char _c)
        {
            int count = 0;
            foreach (char c in exp)
            {
                if (c == _c)
                    count++;
            }
            return count;
        }

        /// <summary>
        /// Function to convert array to create table sql server query 
        /// string { {"column name" , "column type" , "allow null", "primary key" ,"auto increment" } }
        /// </summary>

        public static string ToCreateTable(this string[,] Parameter)
        {
            string parameter = ""; string value = "";
            for (int i = 0; i <= Parameter.GetUpperBound(0); i++)
            {
                if (Parameter[i, 0].ToString() == "" || Parameter[i, 1].ToString() == "")
                    continue;

                value = Parameter[i, 0] + " " + Parameter[i, 1] + " " + Parameter[i, 2];

                if (Parameter.GetLength(1) == 5)
                {
                    if (Parameter[i, 4].ToString() != "")
                    {
                        value += " IDENTITY(1,1) ";
                    }
                }

                if (Parameter.GetLength(1) == 4)
                {
                    if (Parameter[i, 3].ToString() != "")
                    {
                        value += " PRIMARY KEY ";
                    }
                }

                parameter = parameter == "" ? value : parameter = parameter + " , " + value;
            }

            return parameter;

        }
    }
}