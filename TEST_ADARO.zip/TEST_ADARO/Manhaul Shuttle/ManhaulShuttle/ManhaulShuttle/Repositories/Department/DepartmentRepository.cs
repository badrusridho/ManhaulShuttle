﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using ManhaulShuttle.Models;
using MyDAL;

namespace ManhaulShuttle.Repositories.Department
{
    public class DepartmentRepository : DataAccess
    {
        DataTable dt = new DataTable();
        private string QueryString = "";
        private string WhereCondition = "";

        public DepartmentRepository()
        {
            Provider = System.Configuration.ConfigurationManager.AppSettings["Provider"];
            TableName = "Department";
        }

        public List<DepartmentModels> GetDepartment(string[,] parameter)
        {
            List<DepartmentModels> list = new List<DepartmentModels>();
            dt = READ(parameter);
            foreach (DataRow dr in dt.Rows)
            {
                DepartmentModels dm = new DepartmentModels();
                dm.Id_Department = dr["Id_Department"].ToStr();
                dm.Department = dr["Department"].ToStr();
                list.Add(dm);
            }
            return list;
        }

        public DepartmentModels GetSelectedDepartment(string[,] parameters)
        {
            DepartmentModels dm = new DepartmentModels();
            WhereCondition = parameters.ToCondition();
            dt = READ("SELECT * FROM Department " + (WhereCondition != "" ? " WHERE " + WhereCondition : ""), parameters);
            if (dt.Rows.Count > 0)
            {
                dm.Id_Department = dt.Rows[0]["Id_Department"].ToStr();
                dm.Department = dt.Rows[0]["Department"].ToStr();
            }
            return dm;
        }

        public long InsertDepartment(string[,] parameter)
        {
            TableName = "Department";
            return CREATE(parameter);
        }

        public long UpdateDepartment(string[,] parameter, string[] conditions)
        {
            TableName = "Department";
            return UPDATE(parameter, conditions);
        }

        public long DeleteDepartment(string[,] parameters)
        {
            TableName = "Department";
            return DELETE(parameters);
        }
    }
}