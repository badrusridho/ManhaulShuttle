﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using ManhaulShuttle.Models;
using MyDAL;

namespace ManhaulShuttle.Repositories.Route
{
    public class RouteRepository : DataAccess
    {
        DataTable dt = new DataTable();
        private string QueryString = "";
        private string WhereCondition = "";

        public RouteRepository()
        {
            Provider = System.Configuration.ConfigurationManager.AppSettings["Provider"];
            TableName = "Route";
        }

        public List<RouteModels> GetRoute(string[,] parameter)
        {
            List<RouteModels> list = new List<RouteModels>();
            dt = READ(parameter);
            foreach (DataRow dr in dt.Rows)
            {
                RouteModels rm = new RouteModels();
                rm.Id_Route = dr["Id_Route"].ToStr();
                rm.Route = dr["Route"].ToStr();
                list.Add(rm);
            }
            return list;
        }

        public RouteModels GetSelectedRoute(string[,] parameters)
        {
            RouteModels rm = new RouteModels();
            WhereCondition = parameters.ToCondition();
            dt = READ("SELECT * FROM Route " + (WhereCondition != "" ? " WHERE " + WhereCondition : ""), parameters);
            if (dt.Rows.Count > 0)
            {
                rm.Id_Route = dt.Rows[0]["Id_Route"].ToStr();
                rm.Route = dt.Rows[0]["Route"].ToStr();
            }
            return rm;
        }

        public long InsertRoute(string[,] parameter)
        {
            TableName = "Route";
            return CREATE(parameter);
        }

        public long UpdateRoute(string[,] parameter, string[] conditions)
        {
            TableName = "Route";
            return UPDATE(parameter, conditions);
        }

        public long DeleteRoute(string[,] parameters)
        {
            TableName = "Route";
            return DELETE(parameters);
        }
    }
}