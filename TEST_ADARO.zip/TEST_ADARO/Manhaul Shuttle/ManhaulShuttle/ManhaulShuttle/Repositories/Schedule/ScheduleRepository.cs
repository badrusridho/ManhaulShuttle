﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web;
using ManhaulShuttle.Models;
using MyDAL;

namespace ManhaulShuttle.Repositories.Schedule
{
    public class ScheduleRepository : DataAccess
    {
        DataTable dt = new DataTable();
        private string QueryString = "";
        private string WhereCondition = "";

        public ScheduleRepository()
        {
            Provider = System.Configuration.ConfigurationManager.AppSettings["Provider"];
            TableName = "Schedule";
        }

        public List<ScheduleModels> GetSchedule(string[,] parameter)
        {
            List<ScheduleModels> list = new List<ScheduleModels>();
            WhereCondition = parameter.ToCondition();
            dt = READ("SELECT s.*, r.Route, d.Department, p.PickUpDropOff AS PickUp, pd.PickUpDropOff AS DropOff FROM Schedule s INNER JOIN Route r ON r.Id_Route = s.Id_Route INNER JOIN Department d ON d.Id_Department = s.Id_Department INNER JOIN PickUpDropOff p ON p.Id_PickUpDropOff = s.Id_PickUp INNER JOIN PickUpDropOff pd ON pd.Id_PickUpDropOff = s.Id_DropOff" + (WhereCondition == "" ? "" : " WHERE " + WhereCondition), parameter);
            foreach (DataRow dr in dt.Rows)
            {
                ScheduleModels sm = new ScheduleModels();
                sm.Id_Schedule = dr["Id_Schedule"].ToStr();
                sm.Id_Route = dr["Id_Route"].ToStr();
                sm.Time = dr["Time"].ToDate().ToString("hh:mm tt", new CultureInfo("en-US"));
                sm.Name = dr["Name"].ToStr();
                sm.Id_Department = dr["Id_Department"].ToStr();
                sm.Id_PickUp = dr["Id_PickUp"].ToStr();
                sm.Id_DropOff = dr["Id_DropOff"].ToStr();
                sm.Route = dr["Route"].ToStr();
                sm.Department = dr["Department"].ToStr();
                sm.PickUp = dr["PickUp"].ToStr();
                sm.DropOff = dr["DropOff"].ToStr();
                list.Add(sm);
            }
            return list;
        }

        public ScheduleModels GetSelectedSchedule(string[,] parameters)
        {
            ScheduleModels sm = new ScheduleModels();
            WhereCondition = parameters.ToCondition();
            dt = READ("SELECT s.*, r.Route, d.Department, p.PickUpDropOff AS PickUp, pd.PickUpDropOff AS DropOff FROM Schedule s INNER JOIN Route r ON r.Id_Route = s.Id_Route INNER JOIN Department d ON d.Id_Department = s.Id_Department INNER JOIN PickUpDropOff p ON p.Id_PickUpDropOff = s.Id_PickUp INNER JOIN PickUpDropOff pd ON pd.Id_PickUpDropOff = s.Id_DropOff " + (WhereCondition != "" ? " WHERE " + WhereCondition : ""), parameters);
            if (dt.Rows.Count > 0)
            {
                sm.Id_Schedule = dt.Rows[0]["Id_Schedule"].ToStr();
                sm.Id_Route = dt.Rows[0]["Id_Route"].ToStr();
                sm.Time = dt.Rows[0]["Time"].ToDate().ToString("hh:mm tt", new CultureInfo("en-US"));
                sm.Name = dt.Rows[0]["Name"].ToStr();
                sm.Id_Department = dt.Rows[0]["Id_Department"].ToStr();
                sm.Id_PickUp = dt.Rows[0]["Id_PickUp"].ToStr();
                sm.Id_DropOff = dt.Rows[0]["Id_DropOff"].ToStr();
                sm.PickUp = dt.Rows[0]["PickUp"].ToStr();
                sm.DropOff = dt.Rows[0]["DropOff"].ToStr();
            }
            return sm;
        }

        public long InsertSchedule(string[,] parameter)
        {
            TableName = "Schedule";
            return CREATE(parameter);
        }

        public long UpdateSchedule(string[,] parameter, string[] conditions)
        {
            TableName = "Schedule";
            return UPDATE(parameter, conditions);
        }

        public long DeleteSchedule(string[,] parameters)
        {
            TableName = "Schedule";
            return DELETE(parameters);
        }
    }
}